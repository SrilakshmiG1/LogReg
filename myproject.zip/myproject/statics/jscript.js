function username(){
	var un=document.getElementById("fn").value;
	var reg = /^[a-zA-Z\-]+$/;
	var r1=un.match(reg);
	if(r1)
	{
		return true;
	}
	else
	{
		alert("Enter a valid Username");
		document.getElementById("fn").value="";
		document.getElementById("fn").focus();
		return false;
	}
}
function password()
{
	var pswd=/(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}/;
	var p=document.getElementById("pwd").value;
	var res=pswd.match(p);
	if(res)
	{
		return true;
	}
	else
	{
		alert("Enter a valid  Password");
		document.getElementByID("pwd").focus();
		return false;
	}
}
	

