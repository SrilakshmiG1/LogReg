var uname=document.getElementById("uname").value;
var pswd=document.getElementById("pwd").value;

var make={"userName":uname,"password":pswd};
$.ajax({
				type:"POST",
				url:'/logedin/',
				data: JSON.stringify(make),
				contentType:"application/json; charset=utf-8",
				dataType:"json",
				success:function(data){alert("got the data"+data);}
				failure:function(errMsg){
				alert("Error");
				}
				});
