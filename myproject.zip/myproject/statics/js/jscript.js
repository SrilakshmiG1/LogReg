var postUrl="http://127.0.0.1:8000/logedin/";

function onSignIn(){
	var jsonText=JSON.stringify([document.getElementById("uname").value, document.getElementById("pwd").value]);
	jQuery.ajax({
		url:postUrl,
		type:'POST',
		data:jsonText,
		traditional:true,
		dataType:'html',
		sucess:function(result){
			console.log(jsonText)
		},
		error:function(error){
			console.log("hfdjkf")
		}
	});
}
function username(){
	var un=document.getElementById("uname").value;
	var reg = /^[a-zA-Z\-]+$/;
	var r1=un.match(reg);
	if(r1)
	{
		document.getElementById('span-1').innerHTML="";
		return true;
	}
	else
	{
		document.getElementById('span-1').innerHTML="**Enter a valid Username";
		document.getElementById("uname").value="";
		document.getElementById("uname").focus();
		return false;
	}
}
function validate()
{
	var pswd=/(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}/
	var p=document.getElementById("pwd").value;
	var res=p.match(pswd);
	if(res)
	{
		return true;
	}
	else
	{
		alert("Enter a valid  Password");
		document.getElementByID("pwd").focus();
		return false;
	}
}


	

